#ifndef NEIGHBOR_H
#define	NEIGHBOR_H

#ifdef	__cplusplus
extern "C" {
#endif
    extern void GetNeighbors(void);
#ifdef	__cplusplus
}
#endif
#endif	/* NEIGHBOR_H */

