system("gcc -o taxoner64 src/main.c src/alignments.c src/inputs.c src/neighbor.c src/nodes.c -lpthread");
